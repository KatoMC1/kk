package com.ok.autoreply

import android.content.Context
import android.content.SharedPreferences

/**
 * Lưu trữ cài đặt của người dùng (bật/tắt, nội dung tin nhắn, áp dụng cho SMS/gọi nhỡ).
 * Dùng SharedPreferences vì dữ liệu đơn giản, cần đọc nhanh từ BroadcastReceiver
 * (không nên dùng DataStore bất đồng bộ trong receiver có thời gian sống ngắn).
 */
class SettingsRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var isEnabled: Boolean
        get() = prefs.getBoolean(KEY_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_ENABLED, value).apply()

    var replyMessage: String
        get() = prefs.getString(KEY_MESSAGE, "") ?: ""
        set(value) = prefs.edit().putString(KEY_MESSAGE, value).apply()

    var replyToSms: Boolean
        get() = prefs.getBoolean(KEY_REPLY_SMS, true)
        set(value) = prefs.edit().putBoolean(KEY_REPLY_SMS, value).apply()

    var replyToMissedCall: Boolean
        get() = prefs.getBoolean(KEY_REPLY_CALL, true)
        set(value) = prefs.edit().putBoolean(KEY_REPLY_CALL, value).apply()

    /** Tránh trả lời lặp lại nhiều lần cùng một số trong khoảng thời gian ngắn. */
    fun shouldThrottle(phoneNumber: String): Boolean {
        val key = "last_reply_$phoneNumber"
        val last = prefs.getLong(key, 0L)
        val now = System.currentTimeMillis()
        return (now - last) < THROTTLE_WINDOW_MS
    }

    fun markReplied(phoneNumber: String) {
        val key = "last_reply_$phoneNumber"
        prefs.edit().putLong(key, System.currentTimeMillis()).apply()
    }

    companion object {
        private const val PREFS_NAME = "auto_reply_prefs"
        private const val KEY_ENABLED = "key_enabled"
        private const val KEY_MESSAGE = "key_message"
        private const val KEY_REPLY_SMS = "key_reply_sms"
        private const val KEY_REPLY_CALL = "key_reply_call"

        /** Không gửi lại cho cùng 1 số trong vòng 1 giờ, tránh spam nếu họ gọi/nhắn nhiều lần. */
        private const val THROTTLE_WINDOW_MS = 60 * 60 * 1000L
    }
}
