package com.ok.autoreply

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.ok.autoreply.databinding.ActivityMainBinding
import com.ok.autoreply.databinding.ItemPermissionBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var settings: SettingsRepository

    // Mỗi dòng quyền: nhãn hiển thị + hàm kiểm tra trạng thái + hành động khi bấm
    private data class PermissionRow(
        val label: String,
        val isGranted: () -> Boolean,
        val onClick: () -> Unit
    )

    private val requestPermissionsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            refreshPermissionList()
            // Nếu người dùng vừa cấp đủ quyền và switch đang chờ bật, thử bật lại
            if (PermissionHelper.hasAllCorePermissions(this) && pendingEnable) {
                pendingEnable = false
                applyEnabledState(true)
            }
        }

    private val batteryOptimizationLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            refreshPermissionList()
        }

    private var pendingEnable = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        settings = SettingsRepository(this)

        loadSettingsIntoUi()
        setupListeners()
        refreshPermissionList()
    }

    override fun onResume() {
        super.onResume()
        // Người dùng có thể vừa cấp quyền trong Cài đặt hệ thống rồi quay lại app
        refreshPermissionList()
        updateStatusLabel()
    }

    private fun loadSettingsIntoUi() {
        binding.switchEnabled.isChecked = settings.isEnabled
        binding.editMessage.setText(settings.replyMessage)
        binding.checkSms.isChecked = settings.replyToSms
        binding.checkCall.isChecked = settings.replyToMissedCall
        updateStatusLabel()
    }

    private fun setupListeners() {
        binding.switchEnabled.setOnCheckedChangeListener { switchView, isChecked ->
            if (isChecked) {
                if (binding.editMessage.text.isNullOrBlank()) {
                    switchView.isChecked = false
                    Toast.makeText(this, getString(R.string.error_empty_message), Toast.LENGTH_SHORT).show()
                    return@setOnCheckedChangeListener
                }
                if (!PermissionHelper.hasAllCorePermissions(this)) {
                    switchView.isChecked = false
                    pendingEnable = true
                    Toast.makeText(this, getString(R.string.error_grant_permissions_first), Toast.LENGTH_SHORT).show()
                    requestPermissionsLauncher.launch(PermissionHelper.runtimePermissions())
                    return@setOnCheckedChangeListener
                }
            }
            applyEnabledState(isChecked)
        }

        binding.btnSave.setOnClickListener {
            saveSettings()
        }
    }

    /** Lưu trạng thái bật/tắt, khởi động hoặc dừng service tương ứng. */
    private fun applyEnabledState(enabled: Boolean) {
        settings.isEnabled = enabled
        if (enabled) {
            AutoReplyService.start(this)
        } else {
            AutoReplyService.stop(this)
        }
        updateStatusLabel()
    }

    private fun saveSettings() {
        val message = binding.editMessage.text?.toString()?.trim().orEmpty()
        if (message.isEmpty()) {
            Toast.makeText(this, getString(R.string.error_empty_message), Toast.LENGTH_SHORT).show()
            return
        }
        settings.replyMessage = message
        settings.replyToSms = binding.checkSms.isChecked
        settings.replyToMissedCall = binding.checkCall.isChecked
        Toast.makeText(this, getString(R.string.message_saved), Toast.LENGTH_SHORT).show()
    }

    private fun updateStatusLabel() {
        val active = settings.isEnabled && PermissionHelper.hasAllCorePermissions(this)
        binding.tvStatus.text = if (active) getString(R.string.status_active) else getString(R.string.status_inactive)
        binding.tvStatus.setTextColor(
            ContextCompat.getColor(this, if (active) R.color.accent_green else R.color.text_secondary)
        )
    }

    // ---- Danh sách quyền hiển thị bên dưới ----

    private fun buildPermissionRows(): List<PermissionRow> {
        val rows = mutableListOf(
            PermissionRow(
                label = getString(R.string.permission_sms),
                isGranted = { PermissionHelper.hasSmsPermissions(this) },
                onClick = { requestPermissionsLauncher.launch(PermissionHelper.runtimePermissions()) }
            ),
            PermissionRow(
                label = getString(R.string.permission_phone),
                isGranted = { PermissionHelper.hasCallPermissions(this) },
                onClick = { requestPermissionsLauncher.launch(PermissionHelper.runtimePermissions()) }
            )
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            rows.add(
                PermissionRow(
                    label = getString(R.string.permission_notification),
                    isGranted = { PermissionHelper.hasNotificationPermission(this) },
                    onClick = { requestPermissionsLauncher.launch(PermissionHelper.runtimePermissions()) }
                )
            )
        }

        rows.add(
            PermissionRow(
                label = getString(R.string.permission_battery),
                isGranted = { PermissionHelper.isIgnoringBatteryOptimizations(this) },
                onClick = { openBatteryOptimizationSettings() }
            )
        )

        return rows
    }

    private fun refreshPermissionList() {
        val container = binding.permissionsContainer
        container.removeAllViews()

        buildPermissionRows().forEach { row ->
            val itemBinding = ItemPermissionBinding.inflate(LayoutInflater.from(this), container, false)
            itemBinding.tvPermissionName.text = row.label

            val granted = row.isGranted()
            itemBinding.dotStatus.isSelected = granted
            itemBinding.tvPermissionStatus.text = if (granted) {
                getString(R.string.permission_granted)
            } else {
                getString(R.string.permission_not_granted)
            }
            itemBinding.root.setOnClickListener {
                if (!granted) row.onClick()
            }
            container.addView(itemBinding.root)
        }

        updateStatusLabel()
    }

    private fun openBatteryOptimizationSettings() {
        try {
            val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                data = Uri.parse("package:$packageName")
            }
            batteryOptimizationLauncher.launch(intent)
        } catch (e: Exception) {
            // Một số máy (Xiaomi, Oppo...) không hỗ trợ action trên, đưa người dùng tới màn hình chung
            val fallback = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:$packageName")
            }
            batteryOptimizationLauncher.launch(fallback)
        }
    }
}
