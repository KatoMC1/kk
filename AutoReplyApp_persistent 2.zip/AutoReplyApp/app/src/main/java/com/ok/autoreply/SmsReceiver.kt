package com.ok.autoreply

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log

/**
 * Bắt broadcast SMS_RECEIVED. Không cần là default SMS app vì chỉ dùng RECEIVE_SMS
 * (không đọc inbox bằng READ_SMS) — nội dung tin nhắn đến lấy thẳng từ Intent.
 */
class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages.isNullOrEmpty()) return

        // Ghép các phần (nếu SMS bị chia nhiều part) để lấy số người gửi đúng
        val sender = messages[0].originatingAddress
        Log.i(TAG, "Nhận SMS từ: $sender")

        ReplySender.sendAutoReplyIfNeeded(context, sender, ReplySender.Trigger.SMS)
    }

    companion object {
        private const val TAG = "SmsReceiver"
    }
}
