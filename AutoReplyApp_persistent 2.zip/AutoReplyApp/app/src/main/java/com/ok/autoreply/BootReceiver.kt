package com.ok.autoreply

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * Khởi động lại foreground service sau khi điện thoại khởi động lại,
 * hoặc sau khi ứng dụng được cập nhật (MY_PACKAGE_REPLACED).
 * Chỉ khởi động lại nếu người dùng trước đó đã bật tính năng.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) return

        val settings = SettingsRepository(context)
        if (settings.isEnabled && PermissionHelper.hasAllCorePermissions(context)) {
            Log.i(TAG, "Khởi động lại dịch vụ sau boot/cập nhật.")
            AutoReplyService.start(context)
        }
    }

    companion object {
        private const val TAG = "BootReceiver"
    }
}
