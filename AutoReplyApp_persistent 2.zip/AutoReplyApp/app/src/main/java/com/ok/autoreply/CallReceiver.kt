package com.ok.autoreply

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import android.util.Log

/**
 * Phát hiện cuộc gọi nhỡ bằng cách theo dõi chuyển trạng thái điện thoại:
 * RINGING -> IDLE (không đi qua OFFHOOK) nghĩa là cuộc gọi không được trả lời.
 * RINGING -> OFFHOOK nghĩa là người dùng đã bắt máy, không tính là nhỡ.
 *
 * Lưu trạng thái tạm trong companion object vì receiver được tạo mới mỗi lần
 * nhận broadcast, cần nơi giữ state giữa hai lần gọi (RINGING rồi IDLE).
 */
class CallReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return

        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        val incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)

        Log.i(TAG, "Trạng thái cuộc gọi: $state, số: $incomingNumber")

        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                if (!incomingNumber.isNullOrBlank()) {
                    lastRingingNumber = incomingNumber
                }
                wasAnswered = false
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                // Máy đã được bắt (bởi người dùng hoặc cuộc gọi đi) -> không phải nhỡ
                wasAnswered = true
            }
            TelephonyManager.EXTRA_STATE_IDLE -> {
                val number = lastRingingNumber
                if (!wasAnswered && !number.isNullOrBlank()) {
                    Log.i(TAG, "Phát hiện cuộc gọi nhỡ từ: $number")
                    ReplySender.sendAutoReplyIfNeeded(context, number, ReplySender.Trigger.MISSED_CALL)
                }
                lastRingingNumber = null
                wasAnswered = false
            }
        }
    }

    companion object {
        private const val TAG = "CallReceiver"

        @Volatile
        private var lastRingingNumber: String? = null

        @Volatile
        private var wasAnswered: Boolean = false
    }
}
