package com.ok.autoreply

import android.content.Context
import android.telephony.SmsManager
import android.util.Log

/**
 * Chịu trách nhiệm duy nhất: gửi SMS trả lời tự động khi đủ điều kiện
 * (đã bật tính năng, có quyền, có nội dung, chưa gửi lại quá gần đây cho số đó).
 */
object ReplySender {

    private const val TAG = "ReplySender"

    fun sendAutoReplyIfNeeded(context: Context, phoneNumber: String?, trigger: Trigger) {
        if (phoneNumber.isNullOrBlank()) {
            Log.w(TAG, "Không có số điện thoại, bỏ qua.")
            return
        }

        val settings = SettingsRepository(context)

        if (!settings.isEnabled) return

        val triggerAllowed = when (trigger) {
            Trigger.SMS -> settings.replyToSms
            Trigger.MISSED_CALL -> settings.replyToMissedCall
        }
        if (!triggerAllowed) return

        val message = settings.replyMessage
        if (message.isBlank()) {
            Log.w(TAG, "Chưa có nội dung tin nhắn trả lời, bỏ qua.")
            return
        }

        if (!PermissionHelper.hasSmsPermissions(context)) {
            Log.w(TAG, "Thiếu quyền SMS, không thể trả lời.")
            return
        }

        if (settings.shouldThrottle(phoneNumber)) {
            Log.i(TAG, "Đã trả lời số này gần đây, bỏ qua để tránh spam.")
            return
        }

        try {
            val smsManager = context.getSystemService(SmsManager::class.java)
                ?: SmsManager.getDefault()
            val parts = smsManager.divideMessage(message)
            smsManager.sendMultipartTextMessage(phoneNumber, null, parts, null, null)
            settings.markReplied(phoneNumber)
            Log.i(TAG, "Đã gửi trả lời tự động tới $phoneNumber (nguồn: $trigger)")
        } catch (e: Exception) {
            Log.e(TAG, "Gửi SMS trả lời tự động thất bại: ${e.message}", e)
        }
    }

    enum class Trigger { SMS, MISSED_CALL }
}
