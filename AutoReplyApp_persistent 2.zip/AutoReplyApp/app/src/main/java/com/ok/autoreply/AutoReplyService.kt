package com.ok.autoreply

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

/**
 * Foreground service đơn giản chỉ để giữ ứng dụng "sống" trong mắt hệ thống và
 * hiển thị thông báo nhỏ cho người dùng biết tính năng đang hoạt động.
 * Việc bắt SMS/cuộc gọi thực tế do SmsReceiver và CallReceiver xử lý độc lập
 * (BroadcastReceiver luôn hoạt động khi app có quyền, không phụ thuộc service này
 * còn sống hay không) — service ở đây chủ yếu phục vụ tính minh bạch và để hệ
 * thống ít có lý do "diệt" tiến trình ứng dụng hơn.
 *
 * Chiến lược "luôn chạy nền, chỉ dừng khi người dùng chủ động tắt":
 * - START_STICKY: nếu hệ thống diệt process do thiếu RAM, Android sẽ tự gọi lại
 *   onStartCommand(intent = null) để khởi động lại service khi có tài nguyên.
 * - onTaskRemoved(): khi người dùng vuốt app khỏi danh sách "Recent apps" (đây
 *   KHÔNG phải hành động "tắt app" thật sự, chỉ là ẩn task UI), một số ROM sẽ
 *   coi đây là dấu hiệu nên dừng service nền. Ta chủ động khởi động lại service
 *   ngay sau đó nếu tính năng đang được bật, để hành vi nhất quán trên mọi máy.
 * - Việc dừng "thật" duy nhất là khi người dùng bấm tắt switch trong app, hoặc
 *   gỡ cài đặt / Android buộc dừng app trong Cài đặt > Ứng dụng > Buộc dừng —
 *   trường hợp buộc dừng thì không có cách nào (và không nên có cách nào) để
 *   app tự khởi động lại, đây là giới hạn bảo mật cố ý của Android.
 */
class AutoReplyService : Service() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildNotification()
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            notification,
            android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    /**
     * Gọi khi người dùng vuốt app khỏi "Recent apps". Nếu tính năng vẫn đang
     * được bật trong cài đặt, khởi động lại service ngay để không bị một số
     * ROM (Xiaomi, Oppo, Vivo...) coi nhầm đây là hành động tắt hẳn.
     */
    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        val settings = SettingsRepository(applicationContext)
        if (settings.isEnabled) {
            start(applicationContext)
        }
    }

    private fun buildNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notification_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.notification_channel_desc)
        }
        manager.createNotificationChannel(channel)
    }

    companion object {
        const val CHANNEL_ID = "auto_reply_status_channel"
        const val NOTIFICATION_ID = 1001

        fun start(context: Context) {
            val intent = Intent(context, AutoReplyService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, AutoReplyService::class.java))
        }
    }
}
