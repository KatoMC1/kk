# Trả Lời Tự Động (AutoReplyApp)

Ứng dụng Android đơn giản: tự động gửi SMS trả lời khi bạn có **tin nhắn đến** hoặc
**cuộc gọi nhỡ** mà không thể trả lời.

## Cách build (mở bằng Android Studio)

1. Cài **Android Studio** (bản mới nhất) nếu chưa có.
2. Mở Android Studio → **Open** → chọn thư mục `AutoReplyApp` (thư mục gốc chứa
   `build.gradle`, `settings.gradle`).
3. Android Studio sẽ tự tải Gradle Wrapper, SDK, và các thư viện cần thiết
   (yêu cầu máy có Internet). Lần đầu mở có thể mất vài phút.
4. Khi thấy "Gradle sync finished" → bấm nút **Run ▶** (hoặc Shift+F10), chọn
   thiết bị thật hoặc máy ảo, app sẽ được build và cài trực tiếp.
5. Hoặc lấy file cài đặt thủ công: **Build → Build Bundle(s) / APK(s) → Build APK(s)**,
   file `.apk` sẽ nằm trong `app/build/outputs/apk/debug/`.

> Project dùng Kotlin + ViewBinding, `compileSdk`/`targetSdk` = 35 (Android 15),
> `minSdk` = 26 (Android 8.0). Không cần chỉnh gì thêm để build lần đầu.

## Cài lên máy thật — các bước quan trọng

### 1. Cài app (sideload, không qua Play Store)
Vì đây là app cài trực tiếp bằng file APK, **Android 15+ sẽ chặn quyền SMS theo
mặc định** (Google gọi đây là "hard-restricted permission" cho app sideload).
Sau khi cài app lần đầu, nếu xin quyền SMS mà bị xám/không bật được:

1. Mở **Cài đặt → Ứng dụng → Trả Lời Tự Động**.
2. Nhấn vào biểu tượng menu (3 dấu chấm, hoặc "Cài đặt khác" tuỳ máy).
3. Chọn **"Cho phép cài đặt bị hạn chế" / "Allow restricted settings"**.
4. Mở lại app, xin quyền SMS sẽ hoạt động bình thường.

Trên Samsung gọi mục này là **"Thêm"** (More), trên Xiaomi/HyperOS có thể cần
vào **Quyền riêng tư → Quyền đặc biệt** trước.

### 2. Tắt tối ưu hoá pin
Trong app có mục "Bỏ qua tối ưu hoá pin" ở phần *Quyền cần thiết* — nhấn vào đó
để mở thẳng màn hình cho phép. Nếu không tắt, một số máy (Xiaomi, Oppo, Vivo,
Samsung phiên bản cũ) có thể tự tắt service sau vài giờ không dùng máy.

### 3. Cấp đủ quyền runtime
App sẽ xin các quyền sau khi bạn bật công cụ lần đầu:
- **SMS** (gửi/nhận) — để biết có tin nhắn đến và gửi trả lời.
- **Điện thoại** (trạng thái cuộc gọi + lịch sử gọi) — để phát hiện cuộc gọi nhỡ.
- **Thông báo** (Android 13+) — để hiển thị thông báo nhỏ báo đang hoạt động.

## Cách dùng

1. Mở app, nhập nội dung tin nhắn muốn gửi tự động vào ô **"Nội dung tin nhắn trả lời"**.
2. Chọn áp dụng cho **SMS đến**, **cuộc gọi nhỡ**, hoặc cả hai.
3. Nhấn **"Lưu cài đặt"**.
4. Cấp đủ các quyền được liệt kê (chấm đỏ = chưa cấp, chấm xanh = đã cấp).
5. Bật công tắc **"Bật trả lời tự động"** ở đầu trang.
6. Một thông báo nhỏ sẽ xuất hiện báo "Trả lời tự động đang hoạt động" — đây là
   dấu hiệu tính năng đang chạy nền.

Sau khi khởi động lại máy, nếu tính năng đang bật từ trước, ứng dụng sẽ tự khởi
động lại mà không cần mở app.

## Cách hoạt động (tóm tắt kỹ thuật)

- **Không cần** đặt app làm "Ứng dụng SMS mặc định" — chỉ dùng quyền `RECEIVE_SMS`
  (nhận biết có tin tới) và `SEND_SMS` (gửi trả lời), không đọc nội dung tin
  nhắn cũ trong hộp thư.
- Phát hiện **cuộc gọi nhỡ** bằng cách theo dõi trạng thái điện thoại: nếu chuyển
  từ "đang đổ chuông" thẳng sang "rỗi" (không qua "đang nói chuyện") thì coi là
  nhỡ/bị từ chối.
- Có **chống lặp**: mỗi số điện thoại chỉ được trả lời tự động 1 lần mỗi giờ, để
  tránh việc ai đó gọi/nhắn nhiều lần thì bị gửi spam ngược lại.
- Dùng **Foreground Service kiểu `specialUse`** (loại Android 14+ dành cho các
  tính năng không thuộc danh mục có sẵn như định vị, nhạc, gọi điện...) kèm
  thông báo liên tục theo đúng yêu cầu minh bạch của Android.
- `BroadcastReceiver` khởi động lại sau khi máy reboot (`BOOT_COMPLETED`) — loại
  service `specialUse` không bị Android 15 cấm khởi động từ sự kiện này (khác
  với các loại `camera`, `dataSync`, `microphone`, `phoneCall`...).

## Giới hạn cần biết

- Một số hãng máy (Xiaomi, Oppo, Vivo, Huawei) có lớp quản lý pin riêng ngoài
  Android gốc, có thể vẫn giới hạn app chạy nền dù đã tắt tối ưu hoá pin trong
  Cài đặt Android. Nếu thấy tính năng ngừng hoạt động sau một thời gian, tìm
  thêm mục "Khởi động tự động" / "Autostart" trong Cài đặt riêng của hãng máy
  và bật cho app này.
- Vì lý do bảo mật của Android, app **không thể** tự "bắt máy" hộ bạn khi có
  cuộc gọi đến — chỉ có thể gửi SMS trả lời sau khi cuộc gọi kết thúc mà không
  ai bắt máy.
